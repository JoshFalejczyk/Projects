This is a basic RPG I made with GameMaker.  

NOTE: At the moment, most of the code used to make this game is not mine, as I followed the user HeartBeast's GameMaker tutorials on YouTube.  I am currently working to make the code more representative of my own skills, rather than a product of the guidance of another.

CONTROLS: 

Movement: Up/Down/Left/Right Arrows
Dash: F
Attack: C
Pause: Esc